package AAACustomerPortlet.constants;

/**
 * @author LBMHS-PC14-09072022
 */
public class AAACustomerPortletKeys {

	public static final String AAACUSTOMER =
		"AAACustomerPortlet_AAACustomerPortlet";

}