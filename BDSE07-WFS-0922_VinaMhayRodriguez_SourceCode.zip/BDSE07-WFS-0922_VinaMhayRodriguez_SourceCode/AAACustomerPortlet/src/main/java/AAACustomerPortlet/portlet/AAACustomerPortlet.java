package AAACustomerPortlet.portlet;

import AAACustomerPortlet.constants.AAACustomerPortletKeys;
import AAACustomerService.model.aaaCustomer;
import AAACustomerService.service.aaaCustomerLocalServiceUtil;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.util.ParamUtil;

import java.util.Calendar;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

/**
 * @author LBMHS-PC14-09072022
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=AAACustomer",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + AAACustomerPortletKeys.AAACUSTOMER,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class AAACustomerPortlet extends MVCPortlet {
	//CustomerPortlet
			public void addCustomer(ActionRequest request, ActionResponse response)
		            throws Exception {

		        _updateCustomer(request);

		        sendRedirect(request, response);
		    }

		    public void deleteCustomer(ActionRequest request, ActionResponse response)
		        throws Exception {

		        long customerId = ParamUtil.getLong(request, "customerId");

		        aaaCustomerLocalServiceUtil.deleteCustomer(customerId);

		        sendRedirect(request, response);
		    }

		    public void updateCustomer(ActionRequest request, ActionResponse response)
		        throws Exception {

		        _updateCustomer(request);

		        sendRedirect(request, response);
		    }

		    private aaaCustomer _updateCustomer(ActionRequest request)
		        throws PortalException, SystemException {

		    	// Collect all information from JSP
		        long customerId = ParamUtil.getLong(request, "customerId");
		        String name = ParamUtil.getString(request, "customerName");
		        String email = ParamUtil.getString(request, "customerEmail");
		        String address = ParamUtil.getString(request, "customerAddress");
		        String national_Id = ParamUtil.getString(request, "customerNRIC");
		        String contact = ParamUtil.getString(request, "customerContact");
		        long serviceId = ParamUtil.getLong(request, "serviceId");

		        int year = ParamUtil.getInteger(request, "start_dateYear");
		        int month = ParamUtil.getInteger(request, "start_dateMonth");
		        int day = ParamUtil.getInteger(request, "start_dateDay");
		        int hour = ParamUtil.getInteger(request, "start_dateHour");
		        int minute = ParamUtil.getInteger(request, "start_dateMinute");
		        int amPm = ParamUtil.getInteger(request, "start_dateAmPm");

		        if (amPm == Calendar.PM) {
		            hour += 12;
		        }

		        ServiceContext serviceContext = ServiceContextFactory.getInstance(
		            aaaCustomer.class.getName(), request);

		        aaaCustomer customer = null;
		        
		        //Check old customer or new Customer
		        if (customerId <= 0) {
		        	System.out.println("Add Customer ");
		        	//  add Customer Method 
		        	customer = aaaCustomerLocalServiceUtil.addCustomer(
		                serviceContext.getUserId(), serviceContext.getScopeGroupId(),
		                name, email, address, national_Id, contact, month, day, year, hour, minute, serviceId,
		                serviceContext);
		        }
		        else {
		        	System.out.println("Update Customer ");
		        	customer = aaaCustomerLocalServiceUtil.getCustomer(customerId);
		        	//Call update method
		        	customer = aaaCustomerLocalServiceUtil.updateCustomer(
		                serviceContext.getUserId(), customerId, name, email, address, national_Id, contact, month,
		                day, year, hour, minute, serviceId, serviceContext);
		        }
		        
		        return customer;
		    }
}